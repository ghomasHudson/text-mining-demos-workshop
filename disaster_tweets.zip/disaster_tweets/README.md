This is the disaster tweets dataset for the workshop.

It's been split into train and test splits.
